function menufunc(){
    var element = document.getElementById('popup_menu');
   element.classList.toggle('.activ');
}